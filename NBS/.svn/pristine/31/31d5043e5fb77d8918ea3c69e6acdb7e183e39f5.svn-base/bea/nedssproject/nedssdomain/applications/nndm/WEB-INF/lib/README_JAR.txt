==========================================================================

   Third-party Jar Files
   
   
--------------------------------------------------------------------------
1) XSLT Processor: Using Xalan J 2.4.0  
   xalan.jar
   xslt.jar
   xml-apis.jar
   
  Note http://xml.apache.org/xalan-j/index.html
--------------------------------------------------------------------------
2) XML Parser: Using Xerces J 2.1.0; This overrides the one that comes 
default with Tomcat.
   xercesImpl.jar
   xmlParserAPIs.jar
  Note http://xml.apache.org/xerces2-j/index.html
--------------------------------------------------------------------------------
3) JDBC: Using Oracle's 9i JDBC Drivers 1.2 OracleLite
   classes12.jar 
--------------------------------------------------------------------------------
4) JDBC: Using Microsoft SQL Server 2000 JDBC Drivers
   mssqlserver.jar
   msbase.jar
   msutil.jar
   
  Note http://www.microsoft.com/sql/default.asp
--------------------------------------------------------------------------------
5) Servlet jar that came with Tomcat 4.0.1 
   servlet.jar
   
  Note http://jakarta.apache.org/tomcat/index.html
--------------------------------------------------------------------------------   


================================================================================

   Notification Manager Application Jar
   
--------------------------------------------------------------------------------
1) NEDSS Notifiable Disease Message package for the Notification Manager System
  (All objects necessary to identify diseases, and to send a disease message 
  format)
   nndm.jar
--------------------------------------------------------------------------------   